package AtributPeranggg;
import Element.element;

public class gun extends Weapon{
    public gun(String name, element e, double damage){
    this.name = name;
    this.damage = damage;
    this.element = e;
    this.elementDamage = e.getBonusDamage();
    this.totalDamage = this.elementDamage + damage; 
    }
}
