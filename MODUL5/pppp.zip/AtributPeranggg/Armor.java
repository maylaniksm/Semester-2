package AtributPeranggg;
import Element.*;

public class Armor{
    protected double defensePoint;
    public double realDefensePoint;
    protected double elementDefensePoint;
    protected element element;

    public element getElement() {
        return element;
    }

    public double getDefensePoint() {
        return defensePoint;
    }

    public double getRealDefensePoint() {
        return realDefensePoint;
    }

    public double getElementDefensePoint() {
        return elementDefensePoint;
    }

    public void setRealDefensePoint(double realDefensePoint) {
        this.realDefensePoint = realDefensePoint;
    }
    
    public Armor(double defensePoint, element e) {
        this.defensePoint = defensePoint;
        this.element = e;
        this.elementDefensePoint = e.getBonusDefense();
        this.realDefensePoint = this.defensePoint + e.getBonusDefense();
    }
    
    public void reduceArmor(double damage){
        this.realDefensePoint -= damage;
    } 
    
    public void elementType() {
        if (element instanceof api) {
            System.out.println("Element : Api");
        } else if (element instanceof air) {
            System.out.println("Element : Air");
        } else if (element instanceof tanah) {
            System.out.println("Element : Tanah");
        } else{
            System.out.println("Element : -");
        }
    }
}
