package AtributPeranggg;

public interface armorable {
    public void useArmor (Armor a);
}
