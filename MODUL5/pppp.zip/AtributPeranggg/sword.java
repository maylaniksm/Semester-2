package AtributPeranggg;
import Element.element;

/**
 *
 * @author faceb
 */
public class sword extends Weapon{
    public sword(String name, element e, double damage){
    this.name = name;
    this.damage = damage;
    this.element = e;
    this.elementDamage = e.getBonusDamage();
    this.totalDamage = this.elementDamage + damage; 
    }
}
