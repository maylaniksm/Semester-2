package AtributPeranggg;
import Element.*;


public abstract class Weapon {
    protected String name;
    protected double damage;
    protected element element;
    protected double elementDamage;
    protected double totalDamage;

    public String getName() {
        return name;
    }

    public double getDamage() {
        return damage;
    }

    public element getElement() {
        return element;
    }

    public double getElementDamage() {
        return elementDamage;
    }

    public double getTotalDamage() {
        return totalDamage;
    }
    
    public void elementType() {
        if (element instanceof api) {
            System.out.println("Element : Api");
        } else if (element instanceof air) {
            System.out.println("Element : Air");
        } else if (element instanceof tanah) {
            System.out.println("Element : Tanah");
        } else {
            System.out.println("Element : Tidak ada");
        }
    }
}
