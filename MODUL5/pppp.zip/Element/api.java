package Element;

public class api extends element {

    public api() {
        setBonusDamage(400);
        setBonusDefense(500);
    }
    
}
