package Element;

public class tanah extends element {

    public tanah() {
        setBonusDamage(200);
        setBonusDefense(600);
    }
    
}
