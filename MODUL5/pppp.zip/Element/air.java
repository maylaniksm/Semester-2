package Element;

public class air extends element {

    public air() {
        setBonusDamage(500);
        setBonusDefense(500);
    }
    
}
