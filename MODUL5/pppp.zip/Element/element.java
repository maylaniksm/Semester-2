package Element;

public abstract class element {
    private String nama;
    private double bonusDamage;
    private double bonusDefense;

  

    public void setBonusDamage(double bonusDamage) {
        this.bonusDamage = bonusDamage;
    }

    public void setBonusDefense(double bonusDefense) {
        this.bonusDefense = bonusDefense;
    }


    public double getBonusDamage() {
        return bonusDamage;
    }

    public double getBonusDefense() {
        return bonusDefense;
    }
    
    
}
