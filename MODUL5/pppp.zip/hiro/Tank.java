/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hiro;
import AtributPeranggg.*;

/**
 *
 * @author faceb
 */
public class Tank extends Hero implements armorable{
    private Armor a;
    public Tank(int level){
    super(level);
    setHealthPoint(7000 + (level*200));
    setDefense(500 + (level*30));
    setAttackDamage(500 + (level*20));
    }
    
    @Override
    public void spawnIntro(){
        System.out.println("I am immortal.");
    }
    
    @Override
    public void useArmor(Armor a){
        this.a = a;
    }
    
    @Override
    public void checkStatus(){
        System.out.println("Tank");
        super.checkStatus();
        if(a != null){
            System.out.println("TANK IS ARMORED");
            a.elementType();
            System.out.println("Armor Health: "+a.getDefensePoint());
            System.out.println("Armor Element Health: "+a.getElementDefensePoint());
            System.out.println("Total Armor Health: "+a.getRealDefensePoint());
        } else if (a == null){
            System.out.println("TANK IS NOT ARMORED");
        }     
    }
    
    @Override
    public void battleStat(String player){
    super.battleStat(player);
    if(a != null && a.realDefensePoint != 0){
        if(a.realDefensePoint < 0){
        a.realDefensePoint = 0;
        System.out.println(player+" Armor Health: "+(int)a.getRealDefensePoint());
        } else if (a.realDefensePoint != 0){
        System.out.println(player+" Armor Health: "+(int)a.getRealDefensePoint());
        }
    } 
    }

    @Override
    public double totalDamage(){
        double realDamage = getAttackDamage();
        return realDamage;
    }
    
    @Override
    public void reviewDamage(double damage){
    double realDamage = damage - getDefense();
    if(a != null && a.realDefensePoint > 0){
        a.reduceArmor(damage);
    } else if(a != null && a.realDefensePoint == 0 && getHealthPoint() > 0){
    if (realDamage < 0) {
            realDamage = 0;
       }
    setHealthPoint(getHealthPoint()-realDamage);
    }
    else if (a==null){
    setHealthPoint(getHealthPoint()-realDamage);
    }
    if (getHealthPoint() <= 0) {
        setHealthPoint(0);
        setIsDefeated(true);
        }
    }
}    

