package hiro;
import java.util.Scanner;
import Element.*;
import AtributPeranggg.*;

public class mainSlur {
    private Hero player1;
    private Hero player2;

    public Hero getPlayer1() {
        return player1;
    }

    public void setPlayer1(Hero player1) {
        this.player1 = player1;
    }

    public Hero getPlayer2() {
        return player2;
    }

    public void setPlayer2(Hero player2) {
        this.player2 = player2;
    }
    
    private int pilihan;
    private String pilihanString;

    public int getPilihan() {
        return pilihan;
    }

    public void setPilihan(int pilihan) {
        this.pilihan = pilihan;
    }

    public String getPilihanString() {
        return pilihanString;
    }

    public void setPilihanString(String pilihanString) {
        this.pilihanString = pilihanString;
    }
    
    public void title(){
        System.out.println("====== Haidar ======");
    }
    
    public void battle(Hero player1, Hero player2){
        System.out.println("======== PLAYER 1 ========");
        player1.checkStatus();
        System.out.println("");
        System.out.println("======== PLAYER 2 ========");
        player2.checkStatus();
        System.out.println("");
        System.out.println("========= FIGHT ==========");
        int counter = 1;
        while (true){
        System.out.println("======== ROUND "+counter+" =========");
        counter++;
        System.out.println("===== PLAYER 1 TURN ======");
        player1.spawnIntro();
        player1.attack(player2);
        player2.battleStat("Player 2");
        if (player1.isDefeated() == true){
            System.out.println("Player 1 is dead");
            System.out.println("Player 2 WIN");
            break;
        } else if (player2.isDefeated() == true){
            System.out.println("Player 2 is dead");
            System.out.println("Player 1 WIN");
            break;
        }
        System.out.println("");
        System.out.println("===== PLAYER 2 TURN ======");
        player2.spawnIntro();
        player2.attack(player1);
        player1.battleStat("Player 1");
        System.out.println("");
        if (player1.isDefeated() == true){
            System.out.println("Player 1 is dead");
            System.out.println("Player 2 WIN");
            break;
        } else if (player2.isDefeated() == true){
            System.out.println("Player 2 is dead");
            System.out.println("Player 1 WIN");
            break;
        }
        }     
    }
    
    
    public static void main(String[] args) {
        mainSlur main = new mainSlur();
        Scanner sc = new Scanner(System.in);

        element fire = new api();
        element earth = new tanah();
        element water = new air();
  
        main.title();
       
        System.out.println("======== PLAYER 1 ========");
        System.out.println("===== HERO SELECTION =====");
        System.out.println("1. Assassin");
        System.out.println("2. Mage");
        System.out.println("3. Tank");
        System.out.print("Pilih salah satu: ");
        main.setPilihan(sc.nextInt());
        switch (main.getPilihan()) {
            case 1:
                System.out.print("Level: ");
                Assasin P1_ass = new Assasin(sc.nextInt());
                System.out.println("1. Bloody Fire");
                System.out.println("2. Excalibur");
                System.out.println("0. None");
                System.out.print("Pilih senjata yang ingin digunakan: ");                
                main.setPilihan(sc.nextInt());
                switch (main.getPilihan()) {
                    case 1:
                        System.out.println("1. Fire");
                        System.out.println("2. Water");
                        System.out.println("3. Earth");
                        System.out.println("4. Wind");
                        System.out.print("Pilih element: ");
                        main.setPilihan(sc.nextInt());
                        switch (main.getPilihan()){
                            case 1:
                                Weapon gun1 = new gun("Bloody Fire", fire, 500);
                                P1_ass.useWeapon(gun1);
                                break;
                            case 2:
                                Weapon gun2 = new gun("Bloody Fire", water, 500);
                                P1_ass.useWeapon(gun2);
                                break;
                            case 3:
                                Weapon gun3 = new gun("Bloody Fire", earth, 500);
                                P1_ass.useWeapon(gun3);
                                break;
                            default:
                                break;
                        }
                        break;
                    case 2:
                        System.out.println("1. Fire");
                        System.out.println("2. Water");
                        System.out.println("3. Earth");
                        System.out.println("4. Wind");
                        System.out.print("Pilih element: ");
                        main.setPilihan(sc.nextInt());
                        switch (main.getPilihan()){
                            case 1:
                                Weapon sword1 = new sword("Excalibur", fire, 700);
                                P1_ass.useWeapon(sword1);
                                break;
                            case 2:
                                Weapon sword2 = new sword("Excalibur", water, 700);
                                P1_ass.useWeapon(sword2);
                                break;
                            case 3:
                                Weapon sword3 = new sword("Excalibur", earth, 700);
                                P1_ass.useWeapon(sword3);
                                break;
                            default:
                                break;
                        }
                        break;
                    case 0:
                        break;
                    default:
                        break;
                }
                main.setPlayer1(P1_ass);
                break;

            case 2:
                System.out.print("Level: ");
                Mage P1_mage = new Mage(sc.nextInt());
                main.setPlayer1(P1_mage);
                break;

            case 3:
                System.out.print("Level: ");
                Tank P1_tank = new Tank(sc.nextInt());
                System.out.println("Apakah anda ingin menggunakan armor?");
                System.out.println("1. Armor");
                System.out.println("0. None");
                System.out.print("Pilihan: ");
                main.setPilihan(sc.nextInt());
                switch (main.getPilihan()) {
                    case 1:
                        System.out.println("1. Fire");
                        System.out.println("2. Water");
                        System.out.println("3. Earth");
                        System.out.println("4. Wind");
                        System.out.print("Pilih element: ");
                        main.setPilihan(sc.nextInt());
                        switch (main.getPilihan()){
                            case 1:
                                Armor armor1 = new Armor(4000, fire);
                                P1_tank.useArmor(armor1);
                                break;
                            case 2:
                                Armor armor2 = new Armor(4000, water);
                                P1_tank.useArmor(armor2);
                                break;
                            case 3:
                                Armor armor3 = new Armor(4000, earth);
                                P1_tank.useArmor(armor3);
                                break;
                           
                            default:
                                break;
                        }
                        break;
                    case 0:
                        break;
                    default:
                        break;
                }
                main.setPlayer1(P1_tank);
                break;
            default:
                break;
        }
        System.out.println("");
        System.out.println("======== PLAYER 2 ========");
        System.out.println("===== HERO SELECTION =====");
        System.out.println("1. Assassin");
        System.out.println("2. Mage");
        System.out.println("3. Tank");
        System.out.print("Pilih salah satu: ");
        main.setPilihan(sc.nextInt());
        switch (main.getPilihan()) {
            case 1:
                System.out.print("Level: ");
                Assasin P2_ass = new Assasin(sc.nextInt());
                System.out.println("1. Bloody Fire");
                System.out.println("2. Excalibur");
                System.out.println("0. None");
                System.out.print("Pilih senjata yang ingin digunakan: ");
                main.setPilihan(sc.nextInt());
                switch (main.getPilihan()) {
                    case 1:
                        System.out.println("1. Fire");
                        System.out.println("2. Water");
                        System.out.println("3. Earth");
                        System.out.println("4. Wind");
                        System.out.print("Pilih element: ");
                        main.setPilihan(sc.nextInt());
                        switch (main.getPilihan()){
                            case 1:
                                Weapon gun1 = new gun("Bloody Fire", fire, 500);
                                P2_ass.useWeapon(gun1);
                                break;
                            case 2:
                                Weapon gun2 = new gun("Bloody Fire", water, 500);
                                P2_ass.useWeapon(gun2);
                                break;
                            case 3:
                                Weapon gun3 = new gun("Bloody Fire", earth, 500);
                                P2_ass.useWeapon(gun3);
                                break;
                            
                            default:
                                break;
                        }
                        break;
                    case 2:
                        System.out.println("1. Fire");
                        System.out.println("2. Water");
                        System.out.println("3. Earth");
                        System.out.println("4. Wind");
                        System.out.print("Pilih element: ");
                        main.setPilihan(sc.nextInt());
                        switch (main.getPilihan()){
                            case 1:
                                Weapon sword1 = new sword("Excalibur", fire, 700);
                                P2_ass.useWeapon(sword1);
                                break;
                            case 2:
                                Weapon sword2 = new sword("Excalibur", water, 700);
                                P2_ass.useWeapon(sword2);
                                break;
                            case 3:
                                Weapon sword3 = new sword("Excalibur", earth, 700);
                                P2_ass.useWeapon(sword3);
                                break;
                            
                            default:
                                break;
                        }
                        break;
                    case 0:
                        break;
                    default:
                        break;
                }
                main.setPlayer2(P2_ass);
                break;

            case 2:
                System.out.print("Level: ");
                Mage P2_mage = new Mage(sc.nextInt());
                main.setPlayer2(P2_mage);
                break;

            case 3:
                System.out.print("Level: ");
                Tank P2_tank = new Tank(sc.nextInt());
                System.out.println("Apakah anda ingin menggunakan armor?");
                System.out.println("1. Armored");
                System.out.println("0. None");
                System.out.print("Pilihan: ");
                main.setPilihan(sc.nextInt());
                switch (main.getPilihan()) {
                    case 1:
                        System.out.println("1. Fire");
                        System.out.println("2. Water");
                        System.out.println("3. Earth");
                        System.out.println("4. Wind");
                        System.out.print("Pilih element: ");
                        main.setPilihan(sc.nextInt());
                        switch (main.getPilihan()){
                            case 1:
                                Armor armor1 = new Armor(4000, fire);
                                P2_tank.useArmor(armor1);
                                break;
                            case 2:
                                Armor armor2 = new Armor(4000, water);
                                P2_tank.useArmor(armor2);
                                break;
                            case 3:
                                Armor armor3 = new Armor(4000, earth);
                                P2_tank.useArmor(armor3);
                                break;
                            default:
                                break;
                        }
                        break;
                    case 0:
                        break;
                    default:
                        break;
                }
                main.setPlayer2(P2_tank);
                break;
            default:
                break;
        }
        System.out.println("");
        main.battle(main.getPlayer1(), main.getPlayer2());
    }
}
