package hiro;

public abstract class Hero {
    private double healthPoint;
    private double attackDamage;
    private double defense;
    private int level;
    private boolean isDefeated;
    
    public Hero(int level) {
        this.level = level;
        this.isDefeated = false;
    }
    
    public abstract double totalDamage();
    
     public void reviewDamage(double damage) {
        double realDamage = damage - defense;
        if (realDamage < 0) {
            realDamage = 0;
        }
        if(realDamage > 0){
        healthPoint -= realDamage;
        }
        if (healthPoint <= 0) {
            healthPoint = 0;
            isDefeated = true;
        }
    }
    public void battleStat(String player){
        System.out.println(player+" HP: "+(int)healthPoint);
    }
    
    public void attack(Hero target){
        target.reviewDamage(totalDamage());
    }
    
    public abstract void spawnIntro();
    
    public void checkStatus() {
        System.out.println("Health Point: " + getHealthPoint());
        System.out.println("Attack Damage: " + getAttackDamage());
        System.out.println("Defense: " + getDefense());
        System.out.println("Level: " + getLevel());
        System.out.println("Is Defeated: " + isDefeated());
    }

    public double getHealthPoint() {
        return healthPoint;
    }

    public void setHealthPoint(double healthPoint) {
        this.healthPoint = healthPoint;
    }

    public double getAttackDamage() {
        return attackDamage;
    }

    public void setAttackDamage(double attackDamage) {
        this.attackDamage = attackDamage;
    }

    public double getDefense() {
        return defense;
    }

    public void setDefense(double defense) {
        this.defense = defense;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public boolean isDefeated() {
        return isDefeated;
    }

    public void setIsDefeated(boolean isDefeated) {
        this.isDefeated = isDefeated;
    }
    
}
