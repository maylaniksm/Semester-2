package hiro;
import bonusDamage.criticalDamage;
import AtributPeranggg.*;

/**
 *
 * @author faceb
 */
public class Assasin extends Hero implements criticalDamage, weaponable{

    private Weapon w;
    public Assasin(int level){
    super(level);
    setHealthPoint(3000 + (level*90));
    setAttackDamage(800 + (level*30) + (getAttackDamage()*ATK_DMG_BONUS));
    setDefense(300 + (level*15));
    }
    
    @Override
    public void spawnIntro(){
        System.out.println("");
    }
                
    
    @Override
    public void useWeapon(Weapon w){
        this.w = w;
    }
    
    
    @Override
    public void checkStatus(){
        System.out.println("Assasin");
        super.checkStatus();
        if(w != null){
            System.out.println("Weapon: "+w.getName());
            w.elementType();
            System.out.println("Weapon Damage: "+w.getDamage());
            System.out.println("Weapon Element Damage: "+w.getElementDamage());
            System.out.println("Total Weapon Damage: "+w.getTotalDamage());
        }      
    }
    
    @Override
    public double totalDamage(){
    double realDamage = getAttackDamage();
        if (w != null) {
            if (w.getElementDamage() != 0) {
                realDamage += w.getElementDamage();
            }
            realDamage += w.getDamage();
        }
        return realDamage;
    }
}
