/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hiro;
import bonusDamage.magicDamage;

/**
 *
 * @author faceb
 */
public class Mage extends Hero implements magicDamage{
    public Mage(int level){
    super(level);
    setHealthPoint(2500 + (level*85));
    setDefense(200 + (level*10));
    setAttackDamage(700 + (level*35) + (getAttackDamage()*MAGIC_DMG_BONUS));
    }
    
    @Override
    public double totalDamage(){
        double realDamage = getAttackDamage();
        return realDamage;
    }
    
    @Override
    public void spawnIntro(){
        System.out.println("Kuru-kuru. Kururin.");
    }
    
    @Override
    public void checkStatus(){
        System.out.println("Mage");
        super.checkStatus();
    }
}
