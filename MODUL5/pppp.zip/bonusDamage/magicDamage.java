package bonusDamage;

public interface magicDamage {
    double MAGIC_DMG_BONUS = 0.8;
}
