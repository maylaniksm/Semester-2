package bonusDamage;

public interface criticalDamage {
    double ATK_DMG_BONUS = 0.4;
}
