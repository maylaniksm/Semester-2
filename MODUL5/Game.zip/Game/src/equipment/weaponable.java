package equipment;

public interface weaponable{

    public void useWeapon(weapon w);
}

