package system;

public interface magicdamage {
    public double magic_damage_bonus = 0.8;
}
