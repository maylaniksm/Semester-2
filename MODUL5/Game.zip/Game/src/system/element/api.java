package system.element;

public class api extends Element {
    public api(){
        this.attackBonus = 50;
        this.defenseBonus = 500;
    }
}
