package system.element;

public class air extends Element{
    public air(){
        this.attackBonus = 35;
        this.defenseBonus = 350;
    }
}
