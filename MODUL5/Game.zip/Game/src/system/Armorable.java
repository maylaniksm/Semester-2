package system;

import equipment.armor;

public interface Armorable {
    public void useArmor(armor a);
}
