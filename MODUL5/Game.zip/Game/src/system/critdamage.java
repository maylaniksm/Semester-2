package system;

public interface critdamage {
    public double Atk_dmg_bonus = 0.4;
}
